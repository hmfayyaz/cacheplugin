<form id="zip-code-form">
    <input type="text" name="zipCode" id="zipCode" class="form-control border-2" placeholder="Enter ZIP code" required>
    <button type="submit" class="btn btn-success mt-2">Find Plans</button>
    <div id="zip-code-result"></div>
</form>
<div id="loader" style="display: none;"></div>
<div id="response"></div>


