<?php 
/**
 * Plugin Name: getIFPPlanQuotesAPI
 * Version:     1.1.0
 * Author:      hztech
 * Author URI:  https://example.com
 */
require_once plugin_dir_path(__FILE__) . 'inc/getPlans.php';

$getPlansObj = new GetPlans();
